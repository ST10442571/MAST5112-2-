import React, { useState, useEffect } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { View, Text, TextInput, Button, ImageBackground } from 'react-native';

const backgroundImage = require('./image1.png');
const backgroundImage2 = require('./image2.png');
const backgroundImage3 = require('./image3.png');


// Utility Functions
const generateEquation = () => {
  const num1 = Math.floor(Math.random() * 10);
  const num2 = Math.floor(Math.random() * 10);
  const operator = Math.random() < 0.5 ? '+' : '-';
  const solution = operator === '+' ? num1 + num2 : num1 - num2;
  return { question: `What is ${num1} ${operator} ${num2}?`, solution: solution.toString() };
};

const getPowerUp = () => {
  const powerUps = ['Score Doubler', 'Reveal Answer', 'Freeze Timer'];
  return powerUps[Math.floor(Math.random() * powerUps.length)];
};

// Screens
const HomeScreen = ({ navigation }) => (
  <ImageBackground source={backgroundImage3} >
  <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
  
    <Text style={{ fontSize: 24, marginBottom: 20, color:'white', justifyContent:'center',}}>WELCOME TO THE MAGIC MAP PUZZLE GAME!</Text>
    <Button title="Start Training" onPress={() => navigation.navigate('Game')} />
  </View>
  </ImageBackground>
);

const GameScreen = ({ navigation }) => {
  const [equation, setEquation] = useState(generateEquation());
  const [answer, setAnswer] = useState('');
  const [timeLimit, setTimeLimit] = useState(30);
  const [score, setScore] = useState(0);
  const [powerUp, setPowerUp] = useState('');

  useEffect(() => {
    const intervalId = setInterval(() => {
      setTimeLimit(prev => {
        if (prev <= 1) {
          clearInterval(intervalId);
          navigation.navigate('Result', { score });
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(intervalId);
  }, [navigation, score]);

  const handleAnswerSubmit = () => {
    if (answer === equation.solution) {
      setScore(score + 1);
      setEquation(generateEquation());
      setAnswer('');
      setPowerUp(getPowerUp());
    } else {
      navigation.navigate('Result', { score });
    }
  };

  return (
    <ImageBackground source={backgroundImage} >
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text style={{ fontSize: 24, marginBottom: 20, color:'white' }}>{equation.question}</Text>
      <TextInput style={{ width: 200, height: 40, borderColor: 'gray', borderWidth: 1, marginBottom: 20, color:'white'}} 
                 value={answer} onChangeText={setAnswer} keyboardType="numeric" />
      <Button title="Submit" onPress={handleAnswerSubmit} />
      <Text style={{ fontSize: 18, marginTop: 20, color:'white' }}>Time Limit: {timeLimit} seconds</Text>
      {powerUp && <Text style={{ fontSize: 18, marginTop: 20, color:'white' }}>Power Up: {powerUp}</Text>}
    </View>
    </ImageBackground>
  );
};

const ResultScreen = ({ navigation, route }) => {
  const { score } = route.params;
  return (
    <ImageBackground source={backgroundImage2} >
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text style={{ fontSize: 24, marginBottom: 20 }}>YOUR FINAL SCORE IS: {score}</Text>
      <Button title="Continue Training" onPress={() => navigation.navigate('Game')} />
    </View>
    </ImageBackground>
  );
};

// App Component
const Stack = createStackNavigator();
export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="Game" component={GameScreen} />
        <Stack.Screen name="Result" component={ResultScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}